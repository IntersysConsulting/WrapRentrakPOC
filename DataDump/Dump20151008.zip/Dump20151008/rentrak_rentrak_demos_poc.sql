CREATE DATABASE  IF NOT EXISTS `rentrak` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `rentrak`;
-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: rentrak
-- ------------------------------------------------------
-- Server version	5.6.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rentrak_demos_poc`
--

DROP TABLE IF EXISTS `rentrak_demos_poc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rentrak_demos_poc` (
  `recordCode` varchar(10) DEFAULT '-1',
  `rentrakDemoNumber` varchar(20) NOT NULL DEFAULT '-1',
  `rentrakDemoName` varchar(50) DEFAULT '-1',
  `hhUniverseOfDemoInMarket` varchar(20) DEFAULT '-1',
  PRIMARY KEY (`rentrakDemoNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rentrak_demos_poc`
--

LOCK TABLES `rentrak_demos_poc` WRITE;
/*!40000 ALTER TABLE `rentrak_demos_poc` DISABLE KEYS */;
INSERT INTO `rentrak_demos_poc` VALUES ('5','2384','Hispanic','503752'),('5','2386','Asian American','52464'),('5','2422','White','1112030'),('5','2449','$100,000+','348571'),('5','2450','$125,000+','209020'),('5','2452','$200,000+','65161'),('5','2453','$75,000+','581701'),('5','2464','Other','112805'),('5','2465','A35-64','1386882'),('5','3157','A35-54','1056956'),('5','3158','$30,000 - $49,999','397327'),('5','3159','$0 - $29,999','509217'),('5','3160','$0 - $49,999','891715'),('5','3162','Other','63479'),('5','3623','A18-49','1428618'),('5','3624','A50+','1105903'),('5','3625','Presence of Children Ages 11-17 in HH','358343'),('5','3626','Presence of Children Ages 3-10 in HH','382905'),('5','3627','Presence of Children Ages 3-5 in HH','191870'),('5','3628','Presence of Children Ages 6-10 in HH','277729'),('5','3629','M18-24','227040'),('5','3630','M18-34','576585'),('5','3632','M18-49','1068957'),('5','3634','M25-54','1288067'),('5','3635','M35-64','744049'),('5','3636','M50+','740270'),('5','3637','M65+','318064'),('5','3638','W18-24','221247'),('5','3639','W18-34','602040'),('5','3641','W18-49','1099278'),('5','3643','W25-54','1354804'),('5','3644','W35-64','825255'),('5','3645','W50+','833688'),('5','3646','W65+','378378'),('5','379','$50,000 - $74,999','367067'),('5','380','$75,000 - $99,999','233129'),('5','381','$100,000 - $124,999','139552'),('5','5036','W21+','1682220'),('5','5038','W35+','1284693'),('5','5039','W35-54','823934'),('5','5042','M21+','1560000'),('5','5044','M35+','1212778'),('5','5045','M35-54','845784'),('5','5048','Presence of Children Ages 0-5 in HH','313203'),('5','5049','Presence of Children Ages 6-17 in HH','521722'),('5','5050','A21+','1846560'),('5','5051','A21-24','223520'),('5','5052','A21-34','801000'),('5','5053','A25-49','1268747'),('5','5054','A35+','1508731'),('5','585','Single-Person HH, Male','237371'),('5','586','Single-Person HH, Female','265325'),('5','636','Male Present in HH','1393470'),('5','637','Female Present in HH','1521494'),('5','644','A18-24','380044'),('5','649','A65+','509470'),('5','651','A18-34','869247'),('5','652','A25-54','1464238'),('5','677','Children Present in HH','652070'),('5','678','No Children Present in HH','1203240'),('5','680','African American','74259');
/*!40000 ALTER TABLE `rentrak_demos_poc` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-08 14:56:01
