CREATE DATABASE  IF NOT EXISTS `rentrak` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `rentrak`;
-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: rentrak
-- ------------------------------------------------------
-- Server version	5.6.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'rentrak'
--
/*!50003 DROP PROCEDURE IF EXISTS `GetSingleMktGrid` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetSingleMktGrid`(
IN marketID VARCHAR(10),
IN stationID VARCHAR(10),
IN startDate VARCHAR(10),
IN endDate VARCHAR(10),
IN demoID VARCHAR(10))
BEGIN
-- Single Market Grid with Station Name, Program Name and Demo Names
SELECT 
@num := @num + 1 id,
A.marketName,
A.qhDateTime ,
A.putHutDuring15Minutes ,
A.rentrakStationNumber ,
A.rentrakProgramNumber ,
A.ratingDuring15Minutes ,
A.shareDuring15Minutes, 
B.rentrakStationName,
C.rentrakEpisodeTitle,
C.rentrakSeriesName,
C.rentrakSeriesNumber,
D.rentrakDemoName,
D.hhUniverseOfDemoInMarket
FROM Rentrak_Demo_QH_POC A, Rentrak_Stations_POC B, 
Rentrak_Programs_POC C, Rentrak_Demos_POC D,
(SELECT @num := 0) b
WHERE
A.marketCode = marketID AND
A.rentrakStationNumber = stationID AND
A.rentrakDemoNumber = demoID AND
A.rentrakStationNumber = B.rentrakStationNumber 
AND
A.rentrakProgramNumber = 21386099 AND
A.rentrakDemoNumber = D.rentrakDemoNumber
limit 20000
;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetSingleMktGrid_sp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetSingleMktGrid_sp`(
IN marketID VARCHAR(10),
IN stationID VARCHAR(10),
IN startDate VARCHAR(10),
IN endDate VARCHAR(10),
IN demoID VARCHAR(10))
BEGIN
-- DECLARE output VARCHAR(10);
-- DECLARE demo_qh_cursor CURSOR FOR 
SELECT 
rentrakId as Id,
marketName,
qhDateTime ,
putHutDuring15Minutes ,
rentrakStationNumber ,
rentrakProgramNumber ,
ratingDuring15Minutes ,
shareDuring15Minutes
FROM `Rentrak_Demo_QH_POC-old`
WHERE
-- marketCode = marketID AND
rentrakStationNumber = stationID 
-- AND
-- rentrakDemoNumber = demoID
;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetSMData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetSMData`(
IN marketID VARCHAR(10),
IN stationID VARCHAR(10),
IN startDate VARCHAR(10),
IN endDate VARCHAR(10),
IN demoID VARCHAR(10))
BEGIN
select 
@num := @num + 1 id,
A.marketName,
A.qhDateTime ,
A.averageAudienceDuring15Minutes ,
A.rentrakStationNumber ,
A.rentrakProgramNumber ,
A.ratingDuring15Minutes ,
A.shareDuring15Minutes, 
A.stationName,
A.episodeName,
A.programName,
A.rentrakProgramNumber,
A.rentrakDemoNumber,
A.rentrakDemoNumber
from rentrak_demo_qh_poc a where marketcode='753' and rentrakstationnumber='9959' and rentrakdemonumber='379'
and qhDateTime  like '20140709%';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `test`()
BEGIN
   SELECT * FROM rentrak_demo_qh_poc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-08 14:56:05
